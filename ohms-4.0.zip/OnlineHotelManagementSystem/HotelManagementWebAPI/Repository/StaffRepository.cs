﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HotelManagementWebAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace HotelManagementWebAPI.Repository
{
    public class StaffRepository : IStaffRepository
    {
        private readonly OnlineHotelManagementSystemContext _context;

        public StaffRepository(OnlineHotelManagementSystemContext context)
        {
            _context = context;
        }
        public async Task<Staff> Create(Staff staff)
        {
            _context.Staff.Add(staff);

            await _context.SaveChangesAsync();
            return staff;
        }

        public async Task Delete(int UserId)
        {
            var staffToDelete = await _context.Staff.FindAsync(UserId);
            _context.Staff.Remove(staffToDelete);
            _context.SaveChanges();
        }

        public async Task<IEnumerable<Staff>> GetStaffs()
        {
            return await _context.Staff.ToListAsync();
        }


        public async Task Update(Staff staff)
        {
            _context.Entry(staff).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }
        public async Task<Staff> Get(int UserId)
        {
            return await _context.Staff.FindAsync(UserId);
        }
    }
}
