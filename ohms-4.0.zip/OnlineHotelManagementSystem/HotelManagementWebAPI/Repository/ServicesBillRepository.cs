﻿using System.Threading.Tasks;
using HotelManagementWebAPI.Data;
using HotelManagementWebAPI.Interface;
using HotelManagementWebAPI.Models;

namespace HotelManagementWebAPI.Repository
{
    public class ServicesBillRepository : IServicesBillData<ServicesBill>
    {
        private readonly OnlineHotelManagementSystemContext _onlineHotelManagementContext;

        public ServicesBillRepository(OnlineHotelManagementSystemContext onlineHotelManagementContext)
        {
            _onlineHotelManagementContext = onlineHotelManagementContext;
        }
        public async Task<ServicesBill> Get(int BillNo)
        {
            return await _onlineHotelManagementContext.ServicesBill.FindAsync(BillNo);
        }
        public async Task<ServicesBill> AddBill(ServicesBillData servicesBillData)
        {
            var servicesBill = new ServicesBill()
            {
                BillNo = servicesBillData.BillNo,
                Date = servicesBillData.Date,
                Price = servicesBillData.Price,
                Tax = servicesBillData.Tax,
                Units = servicesBillData.Units,
                ItemName = servicesBillData.ItemName,
                MemberCode = servicesBillData.MemberCode,
                ReservationCode = servicesBillData.ReservationCode,
                Amount = servicesBillData.Amount,
            };
            if (servicesBill == null)
            {
                return null;
            }
            await _onlineHotelManagementContext.ServicesBill.AddAsync(servicesBill);
            await _onlineHotelManagementContext.SaveChangesAsync();
            return servicesBill;
        }
    }
}
