﻿using System;
using System.Collections.Generic;

namespace HotelManagementWebAPI.Models
{
    public partial class ServicesBill
    {
        public int BillNo { get; set; }
        public DateTime Date { get; set; }
        public int Price { get; set; }
        public int Tax { get; set; }
        public int Units { get; set; }
        public string ItemName { get; set; }
        public int? MemberCode { get; set; }
        public int? ReservationCode { get; set; }
        public int Amount { get; set; }

        public virtual Guest MemberCodeNavigation { get; set; }
        public virtual MakeReservation ReservationCodeNavigation { get; set; }
    }
}
