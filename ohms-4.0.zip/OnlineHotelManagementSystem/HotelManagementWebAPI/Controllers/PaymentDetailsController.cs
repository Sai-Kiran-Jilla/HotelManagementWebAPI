﻿using System.Threading.Tasks;
using HotelManagementWebAPI.Data;
using HotelManagementWebAPI.Interface;
using HotelManagementWebAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HotelManagementWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaymentDetailsController : ControllerBase
    {
        private readonly IPaymentDetailsData<PaymentDetails> _paymentDetailsRepository;

        public PaymentDetailsController(IPaymentDetailsData<PaymentDetails> paymentDetailsRepository)
        {
            _paymentDetailsRepository = paymentDetailsRepository;
        }
        [HttpGet("{PaymentId}")]
        public async Task<ActionResult<PaymentDetails>> GetPaymentDetails(int PaymentId)
        {
            return await _paymentDetailsRepository.Get(PaymentId);

        }
        [HttpPost]
        public async Task<PaymentDetails> PostPaymentDetails([FromBody] PaymentDetailsData paymentDetailsData)
        {
            var newPaymentDetails = await _paymentDetailsRepository.AddPaymentDetails(paymentDetailsData);
            return newPaymentDetails;
        }
        [HttpDelete("{PaymentId}")]
        public async Task<ActionResult> Delete(int PaymentId)
        {
            var paymentDetailsToDelete = await _paymentDetailsRepository.Get(PaymentId);
            if (paymentDetailsToDelete == null)
            {
                return NotFound();

            }
            await _paymentDetailsRepository.Delete(paymentDetailsToDelete.PaymentId);
            return NoContent();
        }
    }
}
