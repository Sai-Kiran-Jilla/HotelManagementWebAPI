﻿using System;

namespace HotelManagementWebAPI.Data
{
    public class ReservationData
    {
        public int ReservationCode { get; set; }
        public int? RoomId { get; set; }
        public int? MemberCode { get; set; }
        public DateTime CheckInTime { get; set; }
        public DateTime CheckOutTime { get; set; }
        public int NoOfNights { get; set; }
        public int RoomPrice { get; set; }
    }
}
