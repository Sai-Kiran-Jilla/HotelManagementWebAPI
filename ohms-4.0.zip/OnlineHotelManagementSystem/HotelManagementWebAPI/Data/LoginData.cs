﻿namespace HotelManagementWebAPI.Data
{
    public class LoginData
    {
        public string Email { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
    }
}
