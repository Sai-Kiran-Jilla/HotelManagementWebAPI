﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HotelManagementWebAPI.Data;
using HotelManagementWebAPI.Models;

namespace HotelManagementWebAPI.Interface
{
    public interface IGuestData<T>
    {
        Task<T> AddUser(GuestData guestData);
        Task<IEnumerable<Guest>> Get();
        Task<Guest> Get(int MemberCode);
        Task Delete(int MemberCode);
    }
}
