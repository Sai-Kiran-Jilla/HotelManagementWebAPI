﻿using System.Threading.Tasks;
using HotelManagementWebAPI.Data;
using HotelManagementWebAPI.Models;

namespace HotelManagementWebAPI.Interface
{
    public interface IInvoiceData<T>
    {
        Task<Invoice> Get(int InvoiceId);
        Task<Invoice> AddInvoice(InvoiceData invoiceData);
        Task Delete(int InvoiceId);
    }
}
